import prompt from 'prompt-sync';

//Classe
class Dog {
    nome: string = "";
    raca: string = "";
    idade: number = 0;
    cor: string = "";
    energia: number = 0;
    peso: number = 0;
    fome: number = 0;
    sede: number = 0;
    inteligencia: number = 0;
}

//Objeto
const teclado = prompt();

const cachorro: Dog = new Dog();
cachorro.nome = teclado("Digite o nome do seu pet: ");
cachorro.raca = teclado("Digite a raça do pet: ");
cachorro.idade = 0;
cachorro.cor = teclado("Digite a cor do pet: ");
cachorro.energia = 30 + Math.round(Math.random() * 70);
cachorro.fome = 80;
cachorro.sede = 80;
cachorro.peso = 1 + Math.random() * 3;
cachorro.inteligencia = Math.round(Math.random() * 100);

//Entrada e Saída
console.log('cachorro :>> ', cachorro);
//

let opcao: number = 0;

while (opcao != 9) {
    console.log('+---------------------------------------------+');
    console.log('| 1. Treinar ---------------------------------|');
    console.log('| 2. Alimentar -------------------------------|');
    console.log('| 3. Hidratar --------------------------------|');
    console.log('| 4. Dormir ----------------------------------|');
    console.log('| 5. Brincar ---------------------------------|');
    console.log('| 6. Status ----------------------------------|');
    console.log('| 9. Abandonar -------------------------------|');
    console.log('+---------------------------------------------+');

    let opcao = +teclado("Digite o código da opção desejada: ");
    if (opcao == 9) break;

    switch (opcao) {
        case 1:
            // TODO: perde peso, fome aumenta, sede aumenta, energia reduz //
            cachorro.peso -= Math.random() * 1;
            cachorro.fome + - 1 + Math.random() * 4;
            cachorro.sede += 1 + Math.random() * 20;
            cachorro.energia -= 1 + Math.random() * 9;

            status(cachorro);

            if (cachorro.peso <= 0 || cachorro.fome >= 100 || cachorro.sede >= 100 || cachorro.energia <= 0) {
                console.log(`${cachorro.nome} fugiu! Você foi um péssimo dono.`)
                opcao = 9;
            }

            break;

        case 2:
            //TODO: ganha peso, energia aumenta, sede aumenta um pouco//
            
            break;

        case 3:
            //Lógica da Opção 3 //
            break;

        case 4:
            //Lógica da Opção 4 //
            break;

        case 5:
            //Lógica da Opção 5//
            break;

        default:
            console.log("Opção inválida!")
            break;
    }

}

function status(dog: Dog) {
    console.log('dog :>> ', dog);
}